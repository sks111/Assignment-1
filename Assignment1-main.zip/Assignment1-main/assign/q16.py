text ="[['']]"
text ="{[(<<>>)]}"
text ="< />"
text ="<< />>"

middle = "python"
index = (len(text))//2
print (text[:index] + middle + text[index:])
a="hello"
b=""
for i in range(len(a)):
    if (i%2 == 0):
        b+= a[i]
print(b)
lis = "\n Utkrisht Jain \n"
string = lis.strip()
print(string)
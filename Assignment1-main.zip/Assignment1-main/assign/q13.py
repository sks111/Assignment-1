text1 = input("Enter text: ")
print("Text in upper case is ", text1.upper())
print("Text in lower case is ", text1.lower())
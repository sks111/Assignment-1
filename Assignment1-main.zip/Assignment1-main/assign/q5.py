str1 ="hello"
str2="world"
str3 = str2[:2]+str1[2:]+' '+str1[:2]+str2[2:]
print(str3)
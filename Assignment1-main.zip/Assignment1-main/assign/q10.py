mystr="hello"
x= mystr[-1] + mystr[1:-1] + mystr[0]
print(x)
str = input("Enter a string: ")
print("Length of the input string is:", len(str))